package com.project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.project.entity.ServiceTable;
import com.project.service.Services;

import jakarta.annotation.PostConstruct;

@RestController
@CrossOrigin
public class ServiceController {
	
	@Autowired
	private Services services;
	
	@PostMapping("/admin/addService")
	public void addService(@RequestBody ServiceTable service) {
		
	}
	
	
	@PostMapping("/fetchService")
	public List<ServiceTable> fetchService(){
		 return services.getAllServices();
	}
	
	
	
	
	
}
