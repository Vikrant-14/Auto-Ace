package com.project.dto;

public class FeedBackStatus {
	
	private boolean status;
	private String StatusMessage;
	private int feedbackid;
	
	
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	public String getStatusMessage() {
		return StatusMessage;
	}
	public void setStatusMessage(String statusMessage) {
		StatusMessage = statusMessage;
	}
	public int getFeedbackid() {
		return feedbackid;
	}
	public void setFeedbackid(int feedbackid) {
		this.feedbackid = feedbackid;
	}
//	  void setStatus(boolean status2) {
//		// TODO Auto-generated method stub
//		
	}
	 
	
