package com.project.dto;

public class ServiceStatus extends Status{
	
}
