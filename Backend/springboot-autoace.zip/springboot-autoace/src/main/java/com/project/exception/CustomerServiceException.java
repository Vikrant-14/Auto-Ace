//package com.project.exception;
//
//public class CustomerServiceException extends RuntimeException{
////	public CustomerServiceException(String message, Throwable cause) {
////		super(message, cause);
////	}
//
//	public CustomerServiceException(String message) {
//		super(message);
//	}
//}

package com.project.exception;

public class CustomerServiceException extends RuntimeException {

	public CustomerServiceException() {
		super();
		
	}

	public CustomerServiceException(String message, Throwable cause) {
		super(message, cause);
		
	}

	public CustomerServiceException(String message) {
		super(message);
	}
	
}