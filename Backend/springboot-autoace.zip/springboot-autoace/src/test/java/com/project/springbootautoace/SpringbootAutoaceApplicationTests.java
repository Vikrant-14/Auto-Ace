package com.project.springbootautoace;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootAutoaceApplicationTests {

	@Test
	void contextLoads() {
	}

}
